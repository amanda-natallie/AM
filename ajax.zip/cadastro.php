<?php require 'header.php'; ?>

<main class="main">
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                <li class="breadcrumb-item active" aria-current="page">Cadastro</li>
            </ol>
        </div><!-- End .container -->
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-lg-6 col-md-6 ">
                <ul class="checkout-steps">
                    <li>
                        <h2 class="step-title">Cadastro</h2>

                        <form action="#">

                            <div class="form-group required-field">
                                <label>Nome Completo </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Endereço </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Número </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Complemento </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Bairro </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Cidade </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Estado </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>CEP </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Telefone </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>E-mail </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>

                            <div class="form-group required-field">
                                <label>Escolha uma senha </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>


                            <div class="form-group required-field">
                                <label>Confirme a Senha </label>
                                <input type="text" class="form-control" required style="max-width: 100% !important">
                            </div>
                            <div class="form-group required-field">
                                <div class="checkout-steps-action">
                    <a href="checkout-review.html" class="btn btn-primary float-right">PROXIMO</a>
                </div>
                            </div>



                        </form>
                    </li>

                </ul>
            </div>


        </div>

        
    </div>

    <div class="mb-5"></div>
</main>
<?php require 'footer.php'; ?>
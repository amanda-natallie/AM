<aside class="sidebar col-lg-3">
                            <div class="widget widget-dashboard">
                                <h3 class="widget-title">Minha Conta</h3>

                                <ul class="list">
                                    <li class="active"><a href="minha-conta.php">Informações de Conta</a></li>
                                    <li><a href="lista-de-enderecos.php">Lista de Endereços</a></li>
                                    <li><a href="meus-pedidos.php">Meus Pedidos</a></li>
                                    <li><a href="meus-pedidos.php">Rastreie seus Pedidos</a></li>
                                    <li><a href="termos-de-uso.php">Termos de Uso</a></li>
                                    <li><a href="como-comprar.php">Como Comprar</a></li>
                                    <li><a href="seguranca.php">Segurança</a></li>
                                    <li><a href="envio.php">Envio</a></li>
                                    <li><a href="pagamento.php">Pagamento</a></li>
                                    <li><a href="tempo-de-garantia.php">Tempo de Garantia</a></li> 
                                </ul>
                            </div>
                        </aside>